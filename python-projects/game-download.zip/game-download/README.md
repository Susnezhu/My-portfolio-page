#Python game

Python group project

Roskien lajittelupeli. Siirretään roskat oikeaan roskakoriin ja jos niiden arvot ovat samat, roska jää roskakorin sisälle.